public class UserAccount {

    /**
     *
     */
    public String username;
    public String password;
    public String Names;

    // Constructor
    public UserAccount(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.Names = email;
    }

    // Getter methods
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return Names;
    }

    // Setter methods (if needed)
    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setEmail(String email) {
        this.Names = email;
    }

    @Override
    public String toString() {
        return "UserAccount{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", email='" + Names + '\'' +
                '}';
    }
}
